import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { Menu, X, TrendingUp, Repeat, CreditCard, ArrowUpCircle, ArrowDownCircle, Bell, User, LifeBuoy, Shield, Users, Wallet, Lock, UserCheck, FileText, BarChart3, Activity, CheckCircle, Gift } from 'lucide-react';
import { Button } from './ui/button';
import { useAuth } from '@/hooks/useAuth';
import { trpc } from '@/lib/trpc';

export default function MobileNav() {
  const [open, setOpen] = useState(false);
  const { user, loading } = useAuth();
  const [location] = useLocation();
  
  // Notification badges with proper error handling
  const { data: badges } = trpc.admin.notificationBadges.useQuery(undefined, {
    enabled: !loading && user?.role === "admin",
    refetchInterval: 30000,
    retry: false,
  });

  // Hide navigation on auth pages and when not logged in
  const isAuthPage = location.startsWith('/auth/');
  if (isAuthPage || !user) {
    return null;
  }

  const navItems = [
    { href: '/dashboard', label: 'Dashboard', icon: TrendingUp },
    { href: '/convert', label: 'Convert', icon: Repeat },
    { href: '/trading', label: 'Trading', icon: TrendingUp },
    { href: '/deposit', label: 'Deposit', icon: ArrowDownCircle },
    { href: '/withdrawal', label: 'Withdrawal', icon: ArrowUpCircle },
    { href: '/staking', label: 'Staking', icon: CreditCard },
    { href: '/alerts', label: 'Price Alerts', icon: Bell },
    { href: '/portfolio', label: 'Portfolio', icon: User },
    { href: '/referrals', label: 'Referrals', icon: Gift },
    { href: '/support', label: 'Support', icon: LifeBuoy },
  ];

  const adminNavItems = [
    { href: '/admin/panel', label: 'Admin Panel', icon: Shield },
    { href: '/admin/users', label: 'Users', icon: Users },
    { href: '/admin/deposits', label: 'Deposit Management', icon: Wallet },
    { href: '/admin/withdrawal-approval', label: 'Withdrawal Approval', icon: CheckCircle },
    { href: '/admin/staking', label: 'Staking Management', icon: Lock },
    { href: '/admin/kyc-review', label: 'KYC Review', icon: UserCheck },
    { href: '/admin/logs', label: 'Transaction Logs', icon: FileText },
    { href: '/admin/analytics', label: 'Analytics', icon: BarChart3 },
    { href: '/admin/system-health', label: 'System Health', icon: Activity },
    { href: '/admin/support-tickets', label: 'Support Tickets', icon: LifeBuoy },
  ];

  return (
    <>
      {/* Hamburger Button - Only visible on mobile */}
      <Button
        variant="ghost"
        size="icon"
        onClick={() => setOpen(!open)}
        className="md:hidden fixed top-3 right-3 z-[100] bg-background/80 backdrop-blur-sm border border-border hover:bg-accent shadow-lg"
        aria-label="Toggle navigation menu"
      >
        {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
      </Button>

      {/* Overlay */}
      {open && (
        <div
          className="fixed inset-0 bg-black/50 z-40"
          onClick={() => setOpen(false)}
        />
      )}

      {/* Sidebar - Only visible on mobile */}
      <div
        className={`md:hidden fixed top-0 left-0 h-full w-[280px] bg-background border-r border-border z-40 transform transition-transform duration-300 ${
          open ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex flex-col gap-4 p-6 pt-4 overflow-y-auto h-full pb-40">
          <div className="flex items-center gap-2 px-2 mb-4">
            <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center">
              <span className="text-primary-foreground font-bold">BC</span>
            </div>
            <div>
              <p className="font-semibold">BitChange Pro</p>
              <p className="text-xs text-muted-foreground">Professional Exchange</p>
            </div>
          </div>
          
          <nav className="flex flex-col gap-1">
            {navItems.map((item) => (
              <Link key={item.href} href={item.href}>
                <Button
                  variant="ghost"
                  className="w-full justify-start gap-3"
                  onClick={() => setOpen(false)}
                >
                  <item.icon className="h-4 w-4" />
                  {item.label}
                </Button>
              </Link>
            ))}

            {user?.role === 'admin' && (
              <>
                <div className="my-2 border-t border-border" />
                <p className="px-2 text-xs font-semibold text-muted-foreground">ADMIN</p>
                {adminNavItems.map((item) => (
                  <Link key={item.href} href={item.href}>
                    <Button
                      variant="ghost"
                      className="w-full justify-start gap-3 relative"
                      onClick={() => setOpen(false)}
                    >
                      <item.icon className="h-4 w-4" />
                      {item.label}
                      {badges && item.href === "/admin/support-tickets" && badges.pendingTickets > 0 && (
                        <span className="ml-auto inline-flex items-center justify-center w-5 h-5 text-xs font-bold text-white bg-red-600 rounded-full">
                          {badges.pendingTickets > 99 ? "99+" : badges.pendingTickets}
                        </span>
                      )}
                      {badges && item.href === "/admin/kyc-review" && badges.pendingKyc > 0 && (
                        <span className="ml-auto inline-flex items-center justify-center w-5 h-5 text-xs font-bold text-white bg-red-600 rounded-full">
                          {badges.pendingKyc > 99 ? "99+" : badges.pendingKyc}
                        </span>
                      )}
                    </Button>
                  </Link>
                ))}
              </>
            )}
          </nav>
        </div>
      </div>
    </>
  );
}
